// 생산실 방송 화면 ↔ 도우미 연결
document.documentElement.setAttribute('data-bang-helper', '1');
window.addEventListener('message', function (e) {
  if (e.source !== window || !e.data || e.data.bangHelper !== 1) return;
  try { chrome.runtime.sendMessage({ cmd: e.data.cmd }); } catch (x) { }
});