// 방송 시작(duck): 유튜브는 일시정지, 소리 나는 다른 탭은 음소거 → 방송 끝(restore): 원래대로
// 서비스 워커가 잠들어도 되게 상태는 storage에 저장, 3분 넘게 안 돌아오면 자동 복구
async function getState() { return (await chrome.storage.local.get('st')).st || null; }
async function setState(st) { await chrome.storage.local.set({ st: st }); }
async function duck(selfId) {
  if (await getState()) return;
  var st = { paused: [], muted: [], at: Date.now() };
  await setState(st);
  var tabs = await chrome.tabs.query({});
  for (var i = 0; i < tabs.length; i++) {
    var t = tabs[i];
    if (t.id === selfId) continue;
    if (/youtube\.com/.test(t.url || '')) {
      try { var r = await chrome.tabs.sendMessage(t.id, { cmd: 'pause' }); if (r && r.paused) { st.paused.push(t.id); continue; } } catch (e) { }
    }
    if (t.audible && !(t.mutedInfo && t.mutedInfo.muted)) { try { await chrome.tabs.update(t.id, { muted: true }); st.muted.push(t.id); } catch (e) { } }
  }
  await setState(st);
  chrome.alarms.create('bangRestore', { delayInMinutes: 3 });
}
async function restore() {
  var st = await getState(); if (!st) return;
  await chrome.storage.local.remove('st');
  chrome.alarms.clear('bangRestore');
  for (var i = 0; i < st.paused.length; i++) { try { await chrome.tabs.sendMessage(st.paused[i], { cmd: 'resume' }); } catch (e) { } }
  for (var j = 0; j < st.muted.length; j++) { try { await chrome.tabs.update(st.muted[j], { muted: false }); } catch (e) { } }
}
chrome.runtime.onMessage.addListener(function (msg, sender) {
  if (msg.cmd === 'duck') duck(sender.tab && sender.tab.id);
  else if (msg.cmd === 'restore') restore();
});
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'bangRestore') restore(); });
chrome.runtime.onStartup.addListener(restore);