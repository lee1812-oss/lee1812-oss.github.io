// 유튜브: 방송 동안 재생 중인 영상만 멈췄다가 끝나면 이어서 재생
chrome.runtime.onMessage.addListener(function (m, s, send) {
  var vs = Array.prototype.slice.call(document.querySelectorAll('video, audio'));
  if (m.cmd === 'pause') {
    var any = false;
    vs.forEach(function (v) { if (!v.paused && !v.ended) { v.pause(); v.setAttribute('data-bang-paused', '1'); any = true; } });
    send({ paused: any });
  } else if (m.cmd === 'resume') {
    vs.forEach(function (v) { if (v.getAttribute('data-bang-paused')) { v.removeAttribute('data-bang-paused'); var p = v.play(); if (p && p.catch) p.catch(function () { }); } });
    send({ ok: true });
  }
});